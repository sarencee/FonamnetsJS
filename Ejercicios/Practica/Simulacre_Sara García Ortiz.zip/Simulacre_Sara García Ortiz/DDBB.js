"uste strict"

const Missions = []
const Astronauts = []
const Investigations = []